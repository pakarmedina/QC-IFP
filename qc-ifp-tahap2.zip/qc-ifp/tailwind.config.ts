import type { Config } from "tailwindcss";

const config: Config = {
  content: ["./src/**/*.{ts,tsx}"],
  theme: {
    extend: {
      colors: {
        brand: { 50: "#eff6ff", 600: "#1d4ed8", 700: "#1e40af", 800: "#1e3a8a" },
      },
    },
  },
  plugins: [],
};
export default config;
